<?php
/**
 * Header Mobile Search
 *
 * @package Consultare
 */
?>
<div class="mobile-search">
	<?php get_search_form(); ?>
</div><!-- .mobile-search -->
