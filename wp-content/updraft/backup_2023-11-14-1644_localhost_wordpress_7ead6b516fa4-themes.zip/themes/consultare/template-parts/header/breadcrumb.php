<?php
/**
 * Displays breadcrumb
 *
 * @package Consultare
 */

consultare_breadcrumb();
